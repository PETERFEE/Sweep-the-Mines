Name: Peter Feng
Section: 10605
UFL email: fengh@ufl.edu
System: windows
Compiler: g++
SFML version: SFML 3
IDE: clion
Other notes: none